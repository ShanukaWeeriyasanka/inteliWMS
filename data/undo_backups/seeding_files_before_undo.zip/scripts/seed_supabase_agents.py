"""Add 50 linked demo rows to every existing public/twin application table.

Uses TWIN_DATABASE_URL only; never imports the SQLite connection or auth service.
Run with --dry-run first to exercise all database constraints without committing.
Existing rows are never deleted or updated. Reusing a batch name is rejected.
"""

import argparse
from datetime import datetime, timedelta, timezone
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import re
import secrets
import sys
from uuid import uuid4

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import psycopg2
from psycopg2 import sql
from psycopg2.extras import Json, RealDictCursor, execute_values
from config.settings import settings

COUNT = 50
PUBLIC_TABLES = {
    'users', 'security_audit_logs', 'warehouse_locations', 'products',
    'inventory_transactions', 'orders', 'order_items', 'shipments',
    'shift_handoffs', 'returns', 'compliance_incidents', 'conversation_logs',
    'chat_threads', 'chat_messages',
}
TWIN_TABLES = {
    'warehouses', 'floors', 'zones', 'nav_nodes', 'nav_edges', 'racks',
    'shelves', 'bins', 'products', 'stock_locations', 'stock_movements',
    'alerts', 'ui_commands', 'unplaced_stock', 'inventory_product_mappings',
}


class Seeder:
    def __init__(self, conn, schema):
        self.conn = conn
        self.schema = schema
        self.rows = {}
        with conn.cursor() as cur:
            cur.execute("""SELECT table_schema, table_name, column_name, data_type
                FROM information_schema.columns
                WHERE table_schema IN ('public', %s)""", (schema,))
            for namespace, table, column, kind in cur.fetchall():
                self.rows.setdefault((namespace, table), {})[column] = kind
            cur.execute("""SELECT schemaname, tablename FROM pg_tables
                WHERE schemaname IN ('public', %s)""", (schema,))
            actual = set(cur.fetchall())
        expected = {('public', t) for t in PUBLIC_TABLES} | {(schema, t) for t in TWIN_TABLES}
        if actual != expected:
            raise RuntimeError(f'Schema differs from supported agent tables. '
                               f'Missing: {sorted(expected - actual)}; extra: {sorted(actual - expected)}')

    def insert(self, namespace, table, records):
        if len(records) != COUNT:
            raise ValueError(f'{table}: expected {COUNT} demo rows')
        types = self.rows[namespace, table]
        columns = [c for c in records[0] if c in types]
        values = [tuple(Json(row[c]) if types[c] in ('json', 'jsonb') else row[c]
                        for c in columns) for row in records]
        query = sql.SQL('INSERT INTO {}.{} ({}) VALUES %s RETURNING *').format(
            sql.Identifier(namespace), sql.Identifier(table),
            sql.SQL(', ').join(map(sql.Identifier, columns)))
        with self.conn.cursor(cursor_factory=RealDictCursor) as cur:
            return execute_values(cur, query.as_string(cur), values, fetch=True)

    def counts(self):
        parts = [sql.SQL('SELECT {} AS table_name, count(*) AS count FROM {}.{}').format(
            sql.Literal(f'{namespace}.{name}'), sql.Identifier(namespace), sql.Identifier(name))
            for namespace, names in [('public', PUBLIC_TABLES), (self.schema, TWIN_TABLES)]
            for name in sorted(names)]
        with self.conn.cursor() as cur:
            cur.execute(sql.SQL(' UNION ALL ').join(parts))
            return dict(cur.fetchall())


def populate(seed, batch):
    now = datetime.now(timezone.utc)
    times = [now - timedelta(days=60 - i) for i in range(COUNT)]
    tag = f'DEMO-{batch}'
    sku = [f'{tag}-SKU-{i + 1:03d}' for i in range(COUNT)]
    categories = ['Electronics', 'Packaging', 'Safety Equipment', 'Tools', 'Consumables']
    names = ['Barcode Scanner', 'Packing Tape', 'Safety Gloves', 'Hand Trolley', 'Label Roll']
    quantities = [40 + i * 3 for i in range(COUNT)]
    prices = [Decimal('12.50') + Decimal(i * 5) for i in range(COUNT)]
    units = [1 + i % 5 for i in range(COUNT)]
    p = lambda table, rows: seed.insert('public', table, rows)
    t = lambda table, rows: seed.insert(seed.schema, table, rows)

    # Each dummy account is disabled and has a random, undisclosed password.
    users = p('users', [dict(username=f'demo_{batch}_{i + 1:03d}',
        name=f'Demo Staff {i + 1:03d}', email=f'demo.{batch}.{i + 1}@example.invalid',
        hashed_password=hashlib.sha256(
            f'intelliwms_secure_salt_2026:{secrets.token_urlsafe(32)}'.encode()).hexdigest(),
        role=['staff', 'manager', 'admin'][i % 3], is_active=False,
        created_at=times[i], updated_at=times[i]) for i in range(COUNT)])
    user_ids = [f"usr_{u['role']}_{u['id']:03d}" for u in users]
    locations = p('warehouse_locations', [dict(location_code=f'{tag}-LOC-{i + 1:03d}',
        zone=f'Zone {chr(65 + i % 5)}', aisle=str(i // 5 + 1), shelf=f'S{i % 5 + 1:02d}',
        tier=1, max_capacity=500, current_occupancy=quantities[i], status='available',
        created_at=times[i]) for i in range(COUNT)])
    products = p('products', [dict(sku=sku[i], name=f'Demo {names[i % 5]} {i + 1:03d}',
        category=categories[i % 5], quantity=quantities[i], reserved_quantity=0,
        safety_stock=10, reorder_point=20, reorder_quantity=100, unit='units',
        daily_burn_rate=Decimal('2.50'), lead_time_days=3, unit_price=prices[i],
        weight_kg=Decimal('1.25'), location=locations[i]['location_code'],
        aisle=i // 5 + 1, shelf=locations[i]['shelf'], tier='1', bay=f'B{i % 5 + 1:02d}',
        occupancy_pct=Decimal(quantities[i]) / 5, temperature='20 C Ambient',
        is_hazardous=False, max_stack_tier=4, created_at=times[i], updated_at=times[i])
        for i in range(COUNT)])
    p('inventory_transactions', [dict(product_id=products[i]['id'], sku=sku[i],
        transaction_type='INBOUND_RECEIVE', quantity_change=quantities[i],
        previous_quantity=0, new_quantity=quantities[i], source_location='Demo receiving dock',
        destination_location=locations[i]['location_code'], reference_id=f'{tag}-RCV-{i + 1:03d}',
        performed_by=user_ids[i], notes=f'{tag}: synthetic initial stock receipt',
        created_at=times[i]) for i in range(COUNT)])
    orders = p('orders', [dict(order_id=f'{tag}-ORD-{i + 1:03d}',
        customer_name=f'Demo Customer {i + 1:03d}', customer_email=f'customer{i + 1}@example.invalid',
        status='delivered', priority=['low', 'standard', 'rush', 'express'][i % 4],
        total_amount=prices[i] * units[i], shipping_address=f'{i + 1} Demo Road, Colombo',
        created_at=times[i], updated_at=times[i] + timedelta(days=3)) for i in range(COUNT)])
    p('order_items', [dict(order_id=orders[i]['order_id'], sku=sku[i],
        product_name=products[i]['name'], quantity=units[i], unit_price=prices[i],
        picked_quantity=units[i], status='picked', created_at=times[i]) for i in range(COUNT)])
    p('shipments', [dict(order_id=orders[i]['order_id'], tracking_number=f'{tag}-TRK-{i + 1:03d}',
        carrier=['Demo Express', 'Demo Freight'][i % 2], status='delivered',
        dispatched_at=times[i] + timedelta(days=1), estimated_delivery=times[i] + timedelta(days=3),
        notes=f'{tag}: synthetic delivered shipment', created_at=times[i]) for i in range(COUNT)])
    p('returns', [dict(return_id=f'{tag}-RET-{i + 1:03d}', order_id=orders[i]['order_id'],
        sku=sku[i], quantity=1, reason=['Wrong item ordered', 'Packaging damage',
        'Defective unit', 'Customer changed mind'][i % 4],
        condition=['unopened', 'damaged', 'defective', 'opened_good'][i % 4],
        action_taken='pending_inspection', processed_by=user_ids[i],
        created_at=times[i] + timedelta(days=5)) for i in range(COUNT)])
    p('shift_handoffs', [dict(shift_type=['morning', 'afternoon', 'night'][i % 3],
        supervisor=users[i]['name'], summary=f'{tag}: completed {i + 5} receiving and dispatch checks.',
        incidents='No incidents recorded in this demo shift.',
        pending_tasks=f'Inspect return {tag}-RET-{i + 1:03d}.', created_at=times[i]) for i in range(COUNT)])
    p('compliance_incidents', [dict(incident_type=['Blocked aisle', 'Missing PPE', 'Spill',
        'Stacking limit'][i % 4], severity=['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'][i % 4],
        location=locations[i]['location_code'], description=f'{tag}: synthetic compliance inspection finding.',
        reported_by=user_ids[i], status=['open', 'investigating', 'resolved'][i % 3],
        resolved_at=times[i] + timedelta(hours=2) if i % 3 == 2 else None,
        created_at=times[i]) for i in range(COUNT)])
    p('security_audit_logs', [dict(event_id=f'{tag}-SEC-{i + 1:03d}',
        event_type=['login_success', 'access_denied', 'prompt_injection_blocked'][i % 3],
        severity=['INFO', 'WARNING', 'HIGH', 'CRITICAL'][i % 4], user_id=user_ids[i],
        role=users[i]['role'], ip_address=f'192.0.2.{i + 1}',
        details=f'{tag}: synthetic security event for testing.', created_at=times[i]) for i in range(COUNT)])
    agents = ['inventory_agent', 'fulfillment_agent', 'knowledge_agent']
    threads = p('chat_threads', [dict(id=str(uuid4()), user_id=user_ids[i],
        title=f'{tag}: demo query {i + 1:03d}', last_agent=agents[i % 3],
        context_json={'demo_batch': batch}, message_count=1,
        created_at=times[i], updated_at=times[i]) for i in range(COUNT)])
    messages = [f'How many units of {sku[i]} are available?' if i % 3 == 0 else
        f'What is the status of {orders[i]["order_id"]}?' if i % 3 == 1 else
        f'Show the shift handoff for {locations[i]["location_code"]}.' for i in range(COUNT)]
    p('chat_messages', [dict(thread_id=threads[i]['id'], user_id=user_ids[i], role='user',
        content=messages[i], agent_used=agents[i % 3], status='completed',
        request_id=str(uuid4()), meta_json={'demo_batch': batch}, created_at=times[i]) for i in range(COUNT)])
    p('conversation_logs', [dict(session_id=threads[i]['id'], user_id=user_ids[i],
        role=users[i]['role'], message=messages[i], agent_routed_to=agents[i % 3],
        intent=['stock_query', 'order_status', 'shift_handoff'][i % 3],
        response=f'{tag}: demo response for {sku[i]}.', latency_ms=80 + i * 7,
        created_at=times[i]) for i in range(COUNT)])

    with seed.conn.cursor() as cur:
        cur.execute(sql.SQL("SELECT coalesce(max(substring(id from 3)::integer),0) FROM {}.warehouses")
                    .format(sql.Identifier(seed.schema)))
        warehouse_start = cur.fetchone()[0]
        cur.execute(sql.SQL('SELECT coalesce(max(product_no),0) FROM {}.products')
                    .format(sql.Identifier(seed.schema)))
        product_start = cur.fetchone()[0]
    if product_start + COUNT > 99999:
        raise RuntimeError('Not enough five-digit product IDs available.')
    warehouses = t('warehouses', [dict(id=f'WH{warehouse_start + i + 1}',
        name=f'{tag} Warehouse {i + 1:03d}', address=f'{i + 1} Demo Industrial Park',
        created_at=times[i]) for i in range(COUNT)])
    floors = t('floors', [dict(id=f'{w["id"]}-F1', warehouse_id=w['id'],
        level=1, name='Demo Floor 1', width_m=40, height_m=30) for w in warehouses])
    # Two zones/racks and two navigation nodes per occupied demo floor.
    # The remaining 25 demo warehouses have empty floors ready for expansion.
    zones = t('zones', [dict(id=f'{floors[i // 2]["id"]}-Z{i % 2 + 1:02d}',
        floor_id=floors[i // 2]['id'], name=f'{tag} Zone {i % 2 + 1}', type='storage',
        x=2 + i % 2 * 18, y=2, width_m=16, height_m=20) for i in range(COUNT)])
    nodes = t('nav_nodes', [dict(id=f'{floors[i // 2]["id"]}-N{i % 2 + 1:03d}',
        floor_id=floors[i // 2]['id'], type='entrance' if i % 2 == 0 else 'rack_access',
        label=f'{tag} Navigation {i % 2 + 1}', x=10 + i % 2 * 18, y=24) for i in range(COUNT)])
    t('nav_edges', [dict(edge_type='walk', from_node_id=nodes[i]['id'],
        to_node_id=nodes[i ^ 1]['id'], bidirectional=False, blocked=False,
        traverse_s=15) for i in range(COUNT)])
    racks = t('racks', [dict(id=f'{zones[i]["id"]}-R01', zone_id=zones[i]['id'],
        name=f'{tag} Rack {i % 2 + 1}', aliases=[f'{tag} rack {i + 1}'], type='shelf_unit',
        x=5 + i % 2 * 18, y=10, width_m=4, depth_m=2, rotation_deg=0,
        access_node_id=nodes[i]['id']) for i in range(COUNT)])
    shelves = t('shelves', [dict(id=f'{r["id"]}-S01', rack_id=r['id'], level_index=1,
        height_cm=50, max_weight_kg=1000) for r in racks])
    bins = t('bins', [dict(id=f'{s["id"]}-B01', shelf_id=s['id'], position_index=1,
        capacity_units=500, max_weight_kg=1000, status='active') for s in shelves])
    # Activate after balances exist so insertion triggers do not create spurious alerts.
    twin_products = t('products', [dict(product_no=product_start + i + 1, sku=sku[i],
        name=products[i]['name'], aliases=[f'demo item {batch} {i + 1}'],
        category=categories[i % 5], unit='units', weight_kg=Decimal('1.25'),
        reorder_point=20, safety_stock=10, reorder_quantity=100, daily_burn_rate=Decimal('2.50'),
        lead_time_days=3, unit_price=prices[i], is_hazardous=False, is_active=False,
        data_source='demo', created_at=times[i], updated_at=times[i]) for i in range(COUNT)])
    t('stock_locations', [dict(product_id=twin_products[i]['id'], bin_id=bins[i]['id'],
        quantity=quantities[i], lot_code=f'{tag}-LOT-{i + 1:03d}',
        expires_on=(now + timedelta(days=365 + i)).date(), reserved_quantity=0,
        quarantined_quantity=0, data_source='demo', updated_at=times[i]) for i in range(COUNT)])
    # Zero unplaced balances exercise the table without counting the same stock twice.
    t('unplaced_stock', [dict(product_id=product['id'], quantity=0, reserved_quantity=0,
        quarantined_quantity=0, data_source='demo', updated_at=times[i])
        for i, product in enumerate(twin_products)])
    t('stock_movements', [dict(product_id=twin_products[i]['id'], from_bin_id=None,
        to_bin_id=bins[i]['id'], quantity=quantities[i], type='receive', actor=user_ids[i],
        note=f'{tag}: synthetic initial receipt', created_at=times[i]) for i in range(COUNT)])
    t('inventory_product_mappings', [dict(application_product_id=products[i]['id'],
        product_id=twin_products[i]['id'], sku=sku[i], source_system=f'demo:{batch}',
        legacy_snapshot={'demo_batch': batch, 'quantity': quantities[i], 'sku': sku[i]},
        imported_at=times[i]) for i in range(COUNT)])
    with seed.conn.cursor() as cur:
        cur.execute(sql.SQL('UPDATE {}.products SET is_active=true WHERE id=ANY(%s)')
                    .format(sql.Identifier(seed.schema)), ([p['id'] for p in twin_products],))
    # Resolved historical alerts do not create false current inventory warnings.
    t('alerts', [dict(type='low_stock', level='warning', product_id=twin_products[i]['id'],
        bin_id=bins[i]['id'], message=f'{tag}: historical low stock resolved by replenishment.',
        created_at=times[i] - timedelta(hours=1), resolved_at=times[i]) for i in range(COUNT)])
    t('ui_commands', [dict(id=str(uuid4()), session_id=threads[i]['id'],
        query_text=f'Where is {sku[i]}?', payload={'version': '1.1', 'action': 'locate_product',
        'answer_text': f'Demo product is in {bins[i]["id"]}.',
        'product_ids': [twin_products[i]['id']], 'location_ids': [bins[i]['id']],
        'floor_id': zones[i]['floor_id']}, created_at=times[i]) for i in range(COUNT)])
    return {'batch': batch, 'example_sku': sku[0], 'example_order': orders[0]['order_id'],
            'example_bin': bins[0]['id']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--batch', default='agents50', help='Unique batch label (default: agents50)')
    parser.add_argument('--dry-run', action='store_true', help='Validate all inserts then roll back')
    parser.add_argument('--report', type=Path, default=Path('data/seed_reports/supabase_agents50.json'))
    args = parser.parse_args()
    if not re.fullmatch(r'[a-z0-9_]{1,24}', args.batch):
        parser.error('--batch must contain 1-24 lowercase letters, digits or underscores')
    if not re.fullmatch(r'[a-z_][a-z0-9_]*', settings.TWIN_DB_SCHEMA) or settings.TWIN_DB_SCHEMA == 'public':
        parser.error('TWIN_DB_SCHEMA must be a separate valid warehouse schema')
    url = settings.TWIN_DATABASE_URL.replace('postgresql+psycopg2://', 'postgresql://', 1)
    if not url.startswith(('postgresql://', 'postgres://')):
        parser.error('Set TWIN_DATABASE_URL to the Supabase/PostgreSQL database')
    # Prepare report directory before committing any records.
    args.report.parent.mkdir(parents=True, exist_ok=True)
    conn = psycopg2.connect(url, connect_timeout=20)
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT pg_advisory_xact_lock(hashtext('intelliwms_dummy_seed'))")
            cur.execute(sql.SQL('SET LOCAL search_path TO {}, public, extensions')
                        .format(sql.Identifier(settings.TWIN_DB_SCHEMA)))
            cur.execute("SET LOCAL statement_timeout = '60s'")
            cur.execute('SELECT 1 FROM public.users WHERE username = %s', (f'demo_{args.batch}_001',))
            if cur.fetchone():
                raise RuntimeError('This demo batch already exists; use another --batch to add a new one.')
        seed = Seeder(conn, settings.TWIN_DB_SCHEMA)
        before = seed.counts()
        report = populate(seed, args.batch)
        after = seed.counts()
        deltas = {name: after[name] - before[name] for name in before}
        if any(delta != COUNT for delta in deltas.values()):
            raise RuntimeError(f'Expected exactly 50 added rows in every table: {deltas}')
        report.update(dry_run=args.dry_run, rows_added=sum(deltas.values()),
                      tables={name: {'before': before[name], 'added': deltas[name], 'after': after[name]}
                              for name in sorted(before)})
        if args.dry_run:
            conn.rollback()
        else:
            conn.commit()
        args.report.write_text(json.dumps(report, indent=2), encoding='utf-8')
        print(('DRY RUN PASSED (rolled back)' if args.dry_run else 'COMMITTED') +
              f': {sum(deltas.values())} rows across {len(deltas)} tables.')
        for name in sorted(deltas):
            print(f'  {name}: +{deltas[name]} ({before[name]} -> {after[name]})')
        print(f'Report: {args.report}')
    except BaseException:
        conn.rollback()
        raise
    finally:
        conn.close()


if __name__ == '__main__':
    main()
